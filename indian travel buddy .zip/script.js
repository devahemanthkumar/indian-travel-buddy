const searchBox = document.querySelector('.search-box input');
const searchBtn = document.querySelector('.search-box button');
const cityInfo = document.getElementById('city-info');
const weatherInfo = document.getElementById('weather-info');
const map = document.getElementById('map');
const travelLinks = document.getElementById('travel-links');

const cities = [
  "Mumbai", "Delhi", "Bangalore", "Chennai", "Kolkata", "Hyderabad", "Jaipur", "Ahmedabad", "Pune", "Kochi",
  "Agra", "Varanasi", "Goa", "Udaipur", "Rishikesh", "Shimla", "Manali", "Mysore", "Amritsar", "Darjeeling"
];

// Autocomplete
searchBox.addEventListener("input", () => {
  const val = searchBox.value.toLowerCase();
  const suggestions = cities.filter(city => city.toLowerCase().startsWith(val));
  const datalist = document.getElementById("city-suggestions");
  datalist.innerHTML = "";
  suggestions.forEach(city => {
    const option = document.createElement("option");
    option.value = city;
    datalist.appendChild(option);
  });
});

searchBtn.addEventListener('click', () => {
  const city = searchBox.value.trim();
  if (city) {
    fetchCityInfo(city);
    fetchWeather(city);
    displayMap(city);
    showTravelOptions(city);
  }
});

function fetchCityInfo(city) {
  cityInfo.innerHTML = `<h3>About ${city}</h3><p>${city} is one of the top destinations in India known for its unique culture, food, and attractions.</p>`;
}

function fetchWeather(city) {
  const apiKey = 'your_openweathermap_api_key'; // Replace with your API key
  fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`)
    .then(response => response.json())
    .then(data => {
      if (data.main) {
        weatherInfo.innerHTML = `
          <h3>Weather in ${city}</h3>
          <p>Temperature: ${data.main.temp}°C</p>
          <p>Condition: ${data.weather[0].description}</p>
        `;
      } else {
        weatherInfo.innerHTML = `<p>Weather info not found.</p>`;
      }
    })
    .catch(() => {
      weatherInfo.innerHTML = `<p>Unable to fetch weather data.</p>`;
    });
}

function displayMap(city) {
  map.innerHTML = `
    <h3>Map of ${city}</h3>
    <iframe src="https://www.google.com/maps?q=${encodeURIComponent(city)},India&output=embed"></iframe>
  `;
}

function showTravelOptions(city) {
  travelLinks.innerHTML = `
    <h3>Travel Options</h3>
    <ul>
      <li><a href="https://www.makemytrip.com/flights/" target="_blank">Flights to ${city}</a></li>
      <li><a href="https://www.redbus.in/" target="_blank">Buses to ${city}</a></li>
      <li><a href="https://www.irctc.co.in/" target="_blank">Trains to ${city}</a></li>
      <li><a href="https://www.booking.com/searchresults.html?ss=${encodeURIComponent(city)}" target="_blank">Hotels in ${city}</a></li>
    </ul>
  `;
}
